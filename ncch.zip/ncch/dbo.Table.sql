﻿CREATE TABLE [dbo].[menu]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [dept] NCHAR(10) NOT NULL
)
